WINNIECARDHOUSE WEBSITE

FILES
- index.html: complete responsive website, CSS, and JavaScript
- hero-cards.png: generated hero artwork (if included)

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Replace every occurrence of YOUR-EMAIL@example.com with your real business email.
3. Update service area, Whatnot/social links, commission policy, and all business terms.
4. Ensure claims about security, verification, and handling match your actual practices.
5. Test the collection form. It opens a prefilled email draft and does not store form data on a server.

FREE HOSTING OPTIONS
- GitHub Pages: https://pages.github.com/
- Netlify: https://www.netlify.com/
Upload index.html and hero-cards.png together so the hero image can load.
The form uses mailto for a zero-cost starter workflow. A server-backed form requires a form service or backend.
